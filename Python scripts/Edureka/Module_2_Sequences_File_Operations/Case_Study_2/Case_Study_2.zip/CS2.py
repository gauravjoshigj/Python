

nums =set([1,1,2,3,3,3,4,4])
print(len(nums))

d ={"john":40, "peter":45}
print(list(d.keys()))