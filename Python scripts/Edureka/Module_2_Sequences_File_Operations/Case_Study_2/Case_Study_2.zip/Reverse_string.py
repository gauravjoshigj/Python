# By Gaurav
# Problem : reverse a string,
# (You guys !)
#

print (input("Enter a string:")[::-1])